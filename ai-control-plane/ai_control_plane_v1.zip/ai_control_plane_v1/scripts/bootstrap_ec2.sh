#!/usr/bin/env bash
set -euo pipefail

BASE=/opt/ai-workspace
sudo mkdir -p "$BASE"
sudo chown -R "$USER":"$USER" "$BASE"

python3 -m venv "$BASE/.venv"
"$BASE/.venv/bin/pip" install -U pip
"$BASE/.venv/bin/pip" install -r "$BASE/requirements.txt"

cd "$BASE/playwright"
npm install
npx playwright install chromium

echo "Bootstrap complete: $BASE"
