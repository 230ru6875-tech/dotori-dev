#!/usr/bin/env bash
set -euo pipefail
BASE="${AI_WORKSPACE:-/opt/ai-workspace}"
shopt -s nullglob
for f in "$BASE"/tasks/inbox/*.json; do
  "$BASE/.venv/bin/python" "$BASE/runner/task_runner.py" "$f" || true
done
