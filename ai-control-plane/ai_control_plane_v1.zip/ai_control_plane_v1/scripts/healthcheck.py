#!/usr/bin/env python3
from pathlib import Path
import json, datetime, shutil, psutil, os

BASE = Path(os.environ.get("AI_WORKSPACE", "/opt/ai-workspace"))
ts = datetime.datetime.now(datetime.timezone.utc).isoformat()
usage = shutil.disk_usage(BASE if BASE.exists() else "/")
data = {
  "timestamp": ts,
  "cpu_percent": psutil.cpu_percent(interval=1),
  "memory_percent": psutil.virtual_memory().percent,
  "disk_percent": round((usage.used / usage.total) * 100, 2)
}
(BASE / "state").mkdir(parents=True, exist_ok=True)
(BASE / "state/health.json").write_text(json.dumps(data, indent=2), encoding="utf-8")
print(json.dumps(data, indent=2))
