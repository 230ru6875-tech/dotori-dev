const { test, expect } = require('@playwright/test');

test('StrategyBar smoke test', async ({ page }) => {
  const url = process.env.STRATEGYBAR_URL;
  test.skip(!url, 'STRATEGYBAR_URL not configured');

  const consoleErrors = [];
  page.on('console', msg => {
    if (msg.type() === 'error') consoleErrors.push(msg.text());
  });

  const response = await page.goto(url, { waitUntil: 'networkidle' });
  expect(response && response.ok()).toBeTruthy();

  await expect(page.locator('body')).toBeVisible();
  await page.screenshot({ path: '../screenshots/strategybar-latest.png', fullPage: true });

  expect(consoleErrors, consoleErrors.join('\n')).toEqual([]);
});
