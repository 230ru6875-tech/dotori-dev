# Architecture

ChatGPT / AI operator
    |
    v
EC2 /opt/ai-workspace
    |
    +-- projects/
    |     +-- strategybar
    |     +-- hamburgertrader
    |     +-- sermonai
    |
    +-- tasks/inbox
    +-- runner/task_runner.py
    +-- pytest / build / restart
    +-- Playwright
    +-- reports + screenshots + logs + state

No Agent Gateway.

HamburgerTrader:
MarketData → StrategyEngine → RiskEngine → OrderEngine → BrokerAPI

LEVEL 5:
- autonomous LIVE order submit
- cancel/replace
- position management
- autonomous operational recovery

External gateway is intentionally omitted.
Risk controls are implemented as non-bypassable internal invariants.
