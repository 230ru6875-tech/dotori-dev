#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys, json, datetime, shlex, os

BASE = Path(os.environ.get("AI_WORKSPACE", "/opt/ai-workspace"))

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def run(cmd, cwd, logf):
    if isinstance(cmd, str):
        cmd = shlex.split(cmd)
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    logf.write(f"\n$ {' '.join(cmd)}\n")
    logf.write(p.stdout or "")
    logf.write(p.stderr or "")
    logf.flush()
    return p.returncode == 0, p.returncode

def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def main(task_file):
    task = load_json(task_file)
    project = task["project"]
    cfg = load_json(BASE / "config" / "projects" / f"{project}.json")
    repo = Path(cfg["repo_path"])
    task_id = task["task_id"]

    report = {
        "task_id": task_id,
        "project": project,
        "goal": task["goal"],
        "started_at": now(),
        "steps": [],
        "status": "RUNNING"
    }

    log_path = BASE / "logs" / f"{task_id}.log"
    report_path = BASE / "reports" / f"{task_id}.json"
    state_path = BASE / "state" / f"{project}.json"

    with log_path.open("w", encoding="utf-8") as logf:
        if not repo.exists():
            report["status"] = "FAILED"
            report["error"] = f"repo not found: {repo}"
        else:
            for step in task.get("steps", []):
                cmd = cfg.get("commands", {}).get(step)
                if not cmd:
                    report["steps"].append({"name": step, "status": "SKIPPED", "reason": "no command configured"})
                    continue
                ok, rc = run(cmd, str(repo), logf)
                report["steps"].append({"name": step, "status": "PASS" if ok else "FAIL", "returncode": rc})
                if not ok:
                    report["status"] = "FAILED"
                    break
            else:
                report["status"] = "PASS"

        report["finished_at"] = now()
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        state = {
            "project": project,
            "last_task_id": task_id,
            "last_status": report["status"],
            "last_updated": report["finished_at"]
        }
        state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")

    done_dir = BASE / ("tasks/done" if report["status"] == "PASS" else "tasks/failed")
    done_dir.mkdir(parents=True, exist_ok=True)
    src = Path(task_file)
    try:
        src.rename(done_dir / src.name)
    except Exception:
        pass

    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "PASS" else 2

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("usage: task_runner.py <task.json>")
        sys.exit(1)
    sys.exit(main(sys.argv[1]))
