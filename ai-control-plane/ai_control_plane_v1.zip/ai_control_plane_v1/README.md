# AI Development + Trading Control Plane v1

목표:
- Agent Gateway 없이 ChatGPT/원격 AI 작업자가 EC2의 표준 작업 구조를 직접 사용
- 프로젝트별 Task Runner를 통해 수정 → 테스트 → 실행 → 검증 → 결과 기록
- StrategyBar / SermonAI / AI Librarian / HamburgerTrader를 동일 작업 평면에서 관리
- HamburgerTrader는 LEVEL 1~5 자율 수행 가능
- 실거래 통제는 외부 Gateway가 아니라 HamburgerTrader 내부 Risk/Order Engine의 불변규칙으로 처리

## 표준 경로

권장 설치 위치:
`/opt/ai-workspace`

구조:
- `projects/` 실제 Git 저장소
- `runner/` 작업 실행기
- `tasks/` 작업 큐
- `state/` 프로젝트 상태
- `reports/` 검증 결과
- `logs/` 실행 로그
- `screenshots/` Playwright 캡처
- `config/` 프로젝트/정책 설정

## 핵심 실행 루프

Task JSON 생성
→ Runner 실행
→ 프로젝트별 작업 명령 실행
→ pytest/build
→ Playwright 검증
→ 상태/보고서 저장
→ 성공 시 DONE, 실패 시 FAILED

## HamburgerTrader LEVEL 5

`config/policies/hamburgertrader_level5.json`

- `autonomous_level_5: true`
- LIVE 주문/취소/포지션 관리 허용
- 단, broker API를 AI가 임의 호출하는 구조가 아니라
  HamburgerTrader의 Strategy → Risk → Order Engine 흐름을 통해 실행

## 설치

```bash
sudo mkdir -p /opt/ai-workspace
sudo chown -R $USER:$USER /opt/ai-workspace
unzip ai_control_plane_v1.zip -d /opt/ai-workspace
cd /opt/ai-workspace
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Playwright:
```bash
cd playwright
npm install
npx playwright install chromium
```

Runner 테스트:
```bash
python runner/task_runner.py examples/strategybar_task.json
```

systemd 설치:
```bash
sudo cp systemd/ai-task-runner.service /etc/systemd/system/
sudo cp systemd/ai-healthcheck.service /etc/systemd/system/
sudo cp systemd/ai-healthcheck.timer /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now ai-healthcheck.timer
```

## 프로젝트 실제 저장소 연결 예

```bash
mkdir -p /opt/ai-workspace/projects
cd /opt/ai-workspace/projects
git clone <STRATEGYBAR_REPO_URL> strategybar
git clone <HAMBURGERTRADER_REPO_URL> hamburgertrader
git clone <SERMONAI_REPO_URL> sermonai
```

각 프로젝트의 실제 명령은 `config/projects/*.json`에서 수정합니다.
